# Индекс примеров экспортов — ЛОПАТА

Дата: **20.09.2026**. Ровно 11 согласованных сред.

## Что здесь считается примером

Ссылки ниже ведут к **опубликованному содержимому, разбору полей или исходникам**. Статусы различаются: «найден путь» не означает «скачан файл». Детальная карточка каждого источника — в основном исследовании и `SOURCES.json`.

Локальные файлы с суффиксом `.synthetic` составлены самостоятельно. Их текст, даты и идентификаторы вымышлены. Это материал для ранней проверки структурного слоя, **не набор оригинальных экспортов и не свидетельство поддержки всех 11 сервисов**. Нельзя удалять эти метки при передаче в тесты.

## Все 11 сред

### 1. ChatGPT

Публичные материалы: [S03](https://github.com/terminalcommandnewsletter/everything-chatgpt/blob/main/sample/conversations.json); [S04](https://raw.githubusercontent.com/terminalcommandnewsletter/everything-chatgpt/main/sample/conversations.json); [S05](https://portable-ai-memory.org/providers/openai/).

Исторический обезличенный sample прочитан; он содержит заглушки и пропуски и не годится как готовый валидный JSON. Карта полей — наблюдение автора парсера.

Локальный учебный материал: [`01_chatgpt_tree.synthetic.json`](examples/01_chatgpt_tree.synthetic.json)

### 2. Gemini

Публичные материалы: [S08](https://support.google.com/gemini/thread/445018799/takeout-provides-chat-history-but-it-s-a-flat-list-of-messages-rather-than-entire-chats?hl=en-GB); [S10](https://portable-ai-memory.org/providers/google/); [S11](https://github.com/matthewmcneill/gemini-takeout-viewer).

Есть фрагмент Takeout от владельца и описание другого варианта полей. Полного свежего штатного архива нет; README просмотрщика не заменяет такой архив.

Локальный учебный материал: [`04_gemini_activity_html.synthetic.json`](examples/04_gemini_activity_html.synthetic.json); [`05_gemini_activity_details.synthetic.json`](examples/05_gemini_activity_details.synthetic.json)

### 3. Qwen

Публичные материалы: [S14](https://github.com/Rat-S/ai-chat-exporter); [S15](https://github.com/Rat-S/ai-chat-exporter/tree/main/content/parsers).

Поддержка Qwen заявлена экспортёром; файл qwen.js виден в дереве. Точное содержимое обработчика и штатная выходная схема не подтверждены. Синтетический native-файл намеренно не создавался.

Локальный учебный материал: **Нет: неизвестная штатная схема не выдумывалась.**

### 4. Microsoft Copilot

Публичные материалы: [S16](https://support.microsoft.com/en-us/privacy/manage-your-copilot-activity-history-in-the-privacy-dashboard); [S17](https://portable-ai-memory.org/providers/microsoft/).

Официально подтверждён CSV. Конкретные заголовки и варианты — из наблюдений автора парсера; свежий CSV аккаунта не скачан.

Локальный учебный материал: [`06_copilot_history.synthetic.csv`](examples/06_copilot_history.synthetic.csv); [`07_copilot_chat.synthetic.csv`](examples/07_copilot_chat.synthetic.csv); [`08_copilot_prompts_only.synthetic.csv`](examples/08_copilot_prompts_only.synthetic.csv)

### 5. Claude

Публичные материалы: [S19](https://portable-ai-memory.org/providers/anthropic/); [S24](https://github.com/ngallodev-software/conversation-export-workbench/blob/master/sample_data/claude-convo.json).

Есть карта полей и отдельные блоки. Путь sample_data/claude-convo.json найден, но содержимое этого файла не получено. Сохранение веток в штатной выгрузке не гарантируется.

Локальный учебный материал: [`03_claude_blocks.synthetic.json`](examples/03_claude_blocks.synthetic.json)

### 6. DeepSeek

Публичные материалы: [S22](https://github.com/ngallodev-software/conversation-export-workbench); [S25](https://github.com/ngallodev-software/conversation-export-workbench/blob/master/sample_data/deepseek-convo.json).

Реальный предоставленный образец проверен структурно, но приватный. Публичный путь sample найден, файл не получен. В пакет включён только агрегат L03 и независимая учебная форма.

Локальный учебный материал: [`02_deepseek_tree.synthetic.json`](examples/02_deepseek_tree.synthetic.json)

### 7. Grok

Публичные материалы: [S27](https://portable-ai-memory.org/providers/grok/); [S28](https://pypi.org/project/grok-export-viewer/).

Найдены авторское описание prod-grok-backend.json и минимальный публичный пример двойной обёртки. Это не новый архив, полученный из нашего аккаунта.

Локальный учебный материал: [`09_grok_wrapper.synthetic.json`](examples/09_grok_wrapper.synthetic.json)

### 8. Perplexity

Публичные материалы: [S30](https://community.perplexity.ai/t/programmatic-access-to-export-my-data-for-pkm-rag-use/5811); [S31](https://github.com/kylebrodeur/perplexity-exporter).

Пример slug/title/steps находится в README внешнего экспортёра. Схема штатного Export my data не подтверждена этим примером.

Локальный учебный материал: [`10_perplexity_thirdparty.synthetic.json`](examples/10_perplexity_thirdparty.synthetic.json)

### 9. Meta AI / Muse

Публичные материалы: [S14](https://github.com/Rat-S/ai-chat-exporter); [S15](https://github.com/Rat-S/ai-chat-exporter/tree/main/content/parsers); [S33](https://about.fb.com/news/2026/09/introducing-muse-personal-ai-agent/); [S34](https://privacycenter.instagram.com/guide/dyi/).

Есть заявления стороннего экспортёра и meta.js в дереве. Native-архив Meta AI/Muse не прочитан; формы других мессенджеров не выдаются за него.

Локальный учебный материал: **Нет: неизвестная штатная схема не выдумывалась.**

### 10. Character.AI

Публичные материалы: [S35](https://support.character.ai/hc/en-us/articles/30299431702555-How-do-I-export-all-my-data-How-can-I-export-my-chats); [S36](https://github.com/irsat000/CAI-Tools); [S37](https://github.com/irsat000/CAI-Tools/blob/master/ReadOffline.html).

Прочитан старый ReadOffline.html: видны поля встроенного payload и декодирование. Это формат CAI Tools, а не штатная выгрузка аккаунта.

Локальный учебный материал: [`11_caitools_payload.synthetic.json`](examples/11_caitools_payload.synthetic.json)

### 11. Kimi

Публичные материалы: [S39](https://github.com/conreo/kimi-chat-exporter); [S40](https://github.com/conreo/kimi-chat-exporter/blob/main/background.js).

Прочитан исходник стороннего расширения: JSON ListMessages и дерево messages. Содержимое штатного privacy-архива не подтверждено; в расширении обнаружен лимит 50 чатов.

Локальный учебный материал: [`12_kimi_thirdparty_api.synthetic.json`](examples/12_kimi_thirdparty_api.synthetic.json)

## Что проверить на учебных файлах

**01 и 13 — авторское решение против текущей ветки.** Поле `current_node` ведёт через ответ `a2`, но пользователь выбирает `a1` с точной заменой второго предложения. Эталон: «Маяк не горел.\nНа двери таял иней.». Это тест восстановления решения автора, не просто обхода дерева.

**02 — ветвление без указателя.** Сохранить обе альтернативы, не назначать первую каноном. `model` присутствует у пользовательского сообщения. `SYNTHETIC_UNKNOWN_BLOCK` — специально придуманный неизвестный тип, а не реальный тег DeepSeek.

**03 — два представления одного текста.** Поле `text` и текстовый блок дублируются. Не удваивать ответ. В `tool_use` есть вымышленный `synthetic_write` с текстом документа: служебный блок не обязательно бесполезен для восстановления.

**04–05 — два вида активности Gemini.** HTML читается как данные. При отсутствии conversation ID не склеивать записи в один чат только из-за совпавшего слова. Вариант с `details` не считать обязательной формой всех Takeout.

**06–08 — CSV.** Проверить кавычки, запятые, многострочные поля, разные заголовки и неизвестный часовой пояс. Prompt-only CSV должен дать предупреждение об отсутствующих ответах, а не выдуманный текст книги.

**09 — вложенная обёртка Grok.** Прочитать `conversation`, `responses[].response`, родительскую связь и BSON-подобную дату. Это не пример архива X.

**10 — один шаг, две стороны.** Внешний Perplexity JSON содержит вопрос и ответ внутри одного step. Развернуть их в две связанные записи, не приписать оба текста одному автору.

**11 — только payload CAI Tools.** Нет исполняемого HTML. `message` декодируется как URI-строка. Карточка персонажа, пример диалога и фактический разговор — разные материалы.

**12 — Kimi и отсутствующее вложение.** Сохранить `parentId`/`childrenMessageIds`, отделить think от текста; `file.meta` не означает, что файл находится в пакете. Нельзя заявлять полноту аккаунта по одному ответу ListMessages.

## Локальное основание L03

[`private_sample_structure_aggregate.json`](private_sample_structure_aggregate.json) содержит только названия полей и численные показатели реального предоставленного DeepSeek-образца. Это не синтетический агрегат, но и не копия переписки. Его содержимое не позволяет восстановить приватный текст.

## Как дополнять набор настоящими экспортами

Для каждого нового образца записать сервис и конкретную поверхность, дату получения, штатный способ выгрузки либо точное название/версию стороннего инструмента, перечень файлов и наблюдаемую полноту. Сохранить исходный архив отдельно от его нормализованного представления. Контрольные разговоры лучше заранее писать на вымышленном литературном материале.

Обновляемый `main`/`master` по ссылкам не закрепляет версию. При использовании исходника как основания теста сохранить конкретную ревизию и хеш полученных байтов. В текущем пакете `revision_sha: null` означает, что ревизия не была установлена, а не разрешение её угадывать.

**Важное ограничение:** ни один будущий тест на этих синтетических файлах не заменяет хотя бы одного свежего реального образца соответствующего заявленного формата.
